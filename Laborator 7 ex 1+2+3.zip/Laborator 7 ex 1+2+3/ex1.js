function SchimbaProfilul(){
	NumeinJob();
	EducatieinRealizari();
	SchimbareImg();
	FundalSchimbat();
}

function NumeinJob(){
	document.getElementById("NumePrenume").innerHTML="Inginer Programator si Electronist-Envada";

}

function EducatieinRealizari(){
	var disciplina=document.getElementById("Disciplina");
	disciplina.innerHTML="Ocupatia";
	
	var m1=document.getElementById("materia1");
	var p1=document.getElementById("perioada1");
	var l1="https://careers.endava.com/en/Junior-Programmes/Graduates-and-Interns";
	m1.innerHTML="Internship";
	p1.innerHTML="16.06.2026-21.09.2026";
	document.getElementById("linkul1").href=l1;
	
	
	var m2=document.getElementById("materia2");
	var p2=document.getElementById("perioada2");
	var l2="https://www.bosch.ro/cariere/dam-startul-in-cariera/studenti/";
	m2.innerHTML="Experienta din facultate";
	p2.innerHTML="12.10.2024-16.05.2026";
	document.getElementById("linkul2").href=l2;
	
	
	var m3=document.getElementById("materia3");
	var p3=document.getElementById("perioada3");
	var l3="https://fasttrackit.org/curs-dotnet-online/?gclid=Cj0KCQiAsdKbBhDHARIsANJ6-jcPlb9uDcgjlnZSJW1oclbPa2PnoWKyUoLoHrhFPhkHWYmaqh6K1fIaAqmeEALw_wcB";
	m3.innerHTML="Curs C#";
	p3.innerHTML="16.06.2026-21.09.2026";
	document.getElementById("linkul3").href=l3;
	
}

function SchimbareImg(){
	document.getElementById("poza").src="altaviata.jpg.JPG";
	document.getElementById("poza").style.borderColor="green";
	document.getElementById("poza").style.borderStyle="solid";
}

function FundalSchimbat(){
var body=document.getElementById("body");
body.style.backgroundColor="#b6fc92";
body.style.fontFamily="Brush Script MT";

}