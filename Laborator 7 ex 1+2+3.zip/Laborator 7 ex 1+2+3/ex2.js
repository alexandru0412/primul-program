function AdaugaData()
{
    AdaugaText();
    CalculeazaVarsta();
}
function Email()
{
    creazaEmail();
    valideazaEmail();
}
function AdaugaText(){
    var data=document.getElementById("interior");
    data.innerHTML="04.12.2003";
    data.id="nastere";
    document.getElementById("nastere").addEventListener("mouseover",CalculeazaVarsta);
    document.getElementById("nastere").addEventListener("mouseout","04.12.2003");
}
function CalculeazaVarsta(){
    var actual=new Date();
    var vechi=document.getElementById("nastere");
    var an=actual.getFullYear();
    var varsta=Number(an)-Number(vechi.innerHTML.slice(-4));
    vechi.innerHTML="Varsta: "+varsta;

}

function creazaEmail(){

    var input=document.createElement("input");
    input.type="email";
    input.id="epropriuzis";
    input.value="abc@xyz.com";
    input.style.width="300px";
    input.addEventListener("mouseover", valideazaEmail);
    document.getElementById("interior2").appendChild(input);

}

function valideazaEmail()
{
    var input = document.getElementById("epropriuzis");
    var validRegex = /^\S+@\S+\.\S+$/;
    if (input.value.match(validRegex)) {
        console.log("Este email");

    } else {
      alert("Nu este email");
    }
}


